# Algoritmos_Portugol
Exercícios de aula
